db.city_inspections.find({ "address.city": "RIDGEWOOD" });
