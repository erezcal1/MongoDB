db.books.find().limit(5);
