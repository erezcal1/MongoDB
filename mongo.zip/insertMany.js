db.users.insertMany([
  {
    name: "orsula",
    email: "orsula@gmail.com",
  },
  {
    name: "mario",
    email: "mario@gmail.com",
  },
  {
    name: "luigi",
    email: "luigi@gmail.com",
  },
  {
    name: "medusa",
    email: "medusa@gmail.com",
  },
  {
    name: "nagasaki",
    email: "nagasaki@gmail.com",
  },
]);
